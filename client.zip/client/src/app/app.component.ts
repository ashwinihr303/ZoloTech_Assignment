import { Component, OnInit ,ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {SelectItem} from 'primeng/api';
import {Table} from 'primeng/table'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Products';
  errMsg: String = '';
  succMsg: String = '';
  errMsgForm: String = '';
  productsList: any[] = [];
  addProductForm: FormGroup;
@ViewChild("dt",{static:false}) table : Table;
  constructor(private formBuilder: FormBuilder,
    private HttpClient: HttpClient, public router: Router,
    private ActivatedRoute: ActivatedRoute,
    private modalService:NgbModal) { }
  ngOnInit(): void {
    this.createForm();
    this.getAllProducts();
  }
  //create form fields and add validators
  private createForm() {
    this.addProductForm = this.formBuilder.group({
      pName: ['', Validators.required],
      model: ['', Validators.required],
      fabric: ['', Validators.required],
      price: ['', Validators.required],
      manufacturer: ['', Validators.required],
      dateOfManufacture: ['', Validators.required]
    });
  }
  //to reset all the error messages
  private resetMsgs() {
    if (this.errMsg) this.errMsg = '';
    if (this.succMsg) this.succMsg = '';
    if (this.errMsgForm) this.errMsgForm = '';

  }
  //open modal to collect deatils to add new product
  public openAddProdModal(content){
    this.modalService.open(content,{
      ariaLabelledBy:'modal-basic-title',
      backdrop:'static'
    });
  }
  //close modal pop up
  public closeAddProdModal(content){
    this.resetMsgs();
    this.addProductForm.reset();
    content.close();
  }
  //api to fetch all products on page load
  private getAllProducts() {
    this.HttpClient.get<any>('http://localhost:3000/products/all').subscribe(data => {
      this.productsList = data;
    },
      (error) => {
        console.log(error);
        this.errMsg = error;
      });
  }
//api to add new product
  public addProduct() {
    this.resetMsgs();
    this.HttpClient.post<any>('http://localhost:3000/products/add', this.addProductForm.value).subscribe(data => {
      this.productsList = data;
      this.succMsg = 'Details added successfully'
    },
      (error) => {
        console.log(error);
        this.errMsgForm = error.error.message;
      });
  }



}
