var express = require('express');
var router = express.Router();
var bl = require('../public/javascripts/bl');

//to fetch all the product details
router.get('/all', async(req, res, next) => {
    try {
        const response = await bl.getAllProducts();
        res.status(200).send(response);
    } catch (err) {
        next(err);
    }
});

//add new data to db
router.post('/add', async(req, res, next) => {
    try {
        const productData = req.body;
        const response = await bl.addProduct(productData);
        res.status(201).send(response);

    } catch (err) {
        next(err);
    }
});

//to fetch product details with product name
router.get('/:productName', async(req, res, next) => {
    try {
        const productName = req.params.productName;
        const response = await bl.getProductByName(productName);
        res.status(200).send(response);
    } catch (err) {
        next(err);
    }
});

module.exports = router;